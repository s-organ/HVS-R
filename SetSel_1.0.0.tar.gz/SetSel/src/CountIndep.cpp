/* Method for counting independent sets of a graph.

 */

#include <cstdlib>
#include <iostream>
#include <cmath>
#include "Set.h"
#include <R.h>

using namespace std;

unsigned int npowers=0;
double *powers;



unsigned int target_n;
double q=0.05;

//function to satisfy S_n>c

double target(double c){
  //  return exp(log(2)*(1/(q*c)));

  return exp(log(2)*((target_n*(target_n-1)*c+0.02)/(q*(1-c+target_n*c))));
};



inline unsigned int random(unsigned int n){
  //generates a random number in the range 0 to n-1.

  double ru=unif_rand();
  return(floor(ru*n));
  
//  unsigned int r=rand();
//  for(;r>(RAND_MAX/n)*n;r=rand());
//  return r%n;
};

class graph{ //a graph labelled by real numbers
  unsigned int n;
  double *edges;
public:
  graph(){n=0;edges=NULL;}
  graph(unsigned int no):n(no){edges=new double[n*n];}
  graph(unsigned int no,const double *ed):n(no){edges=new double[n*n];for(unsigned int i=0;i<n*n;i++){edges[i]=ed[i];};};
  void set_size(unsigned int no){n=no;edges=new double[n*n];};
  void random();
  //  void print(double c);
  double indep_prob(double c);
  double indep_prob_sample(double c,unsigned int nsamp=1000);
  double indep_prob_sample_inc(double c,unsigned int nsamp=1000);
  double indep_inc_sample(double c,unsigned int nsamp=1000);
  double indep_inc_sample2(double c,unsigned int nsamp);
  double indep_inc_sample3(double (*f)(double)=target,unsigned int nsamp=10000,double step=1);
  double indep_inc_sample4(double thresh,unsigned int nsamp=10000,double step=1);
  graph sort(double c);
  friend class setgraph;
};

void quicksort(unsigned int n,unsigned int* vals,unsigned int* to,unsigned int *indices,unsigned int* indicesto){
  //n is the length of the list
  //vals is the values
  //indices are the indices
  if(n==0){
    return;
  }else if(n==1){
    *to=*vals;
    *indicesto=*indices;
    return;
  };
  
  unsigned int separator=vals[0];
  unsigned int* lowind=to;
  unsigned int* lowindind=indicesto;
  unsigned int* highind=to+n-1;
  unsigned int* highindind=indicesto+n-1;
  for(unsigned int i=1;i<n;i++){
    if(vals[i]<separator){
      *(lowind++)=vals[i];
      *(lowindind++)=indices[i];
    }else{
      *(highind--)=vals[i];
      *(highindind--)=indices[i];
    };
  };
  unsigned int nlow=lowind-to;
  *lowind=separator;
  *lowindind=indices[0];
  quicksort(nlow,to,vals,indicesto,indices);
  quicksort(n-1-nlow,lowind+1,vals+nlow+1,indicesto+nlow+1,indices+nlow+1);  
};

graph graph::sort(double c){
  // count vertex degrees
  unsigned int *degree=new unsigned int[n];
  for(unsigned int i=0;i<n;i++){
    degree[i]=0;
    for(unsigned int j=0;j<n;j++){
      degree[i]+=((*(edges+i*n+j))>=c);
    };
  };

  //Sort degree sequence

  unsigned int *index=new unsigned int[n];
  for(unsigned int i=0;i<n;i++){
    index[i]=i;
  };
  unsigned int *temp=new unsigned int[n];
  unsigned int *tempind=new unsigned int[n];

  quicksort(n,degree,temp,index,tempind);

  graph ans(n);

  
  for(unsigned int i=0;i<n;i++){
    for(unsigned int j=0;j<n;j++){
      *(ans.edges+i*n+j)=*(edges+tempind[i]*n+tempind[j]);
    };
  };	

  return ans;
  
};

class setgraph{
  unsigned int n;
  set *edges;
public:
  setgraph(const graph&G,double c);
  double indep_prob();    
  double indep_prob(const set &remain);   
  double indep_prob(const set & remain,set *temp);
  double indep_inc_sample(unsigned int nsamp);
  double indep_inc_sample2(unsigned int nsamp);
};

setgraph::setgraph(const graph&G,double c){
  n=G.n;
  set::setmaxcard(n);
  edges=new set[n];
  unsigned int *temp=new unsigned int[n];
  for(unsigned int i=0;i<n;i++){
    for(unsigned int j=0;j<n;j++){
      *(temp+j)=*(G.edges+i*n+j)<c;
    };
    edges[i].assign(n,temp);
  };
};


double setgraph::indep_prob(){
  set empty(n);
  set all=empty.complement();

  // remove all singletons 
  for(unsigned int i=0;i<n;i++){
    if(edges[i].ni(i)){
      all.remove(i);
    };
  };

  if(all.empty()){
    return 1;
  };

  unsigned int ac=all.card();
  if(npowers<ac){
    if(powers){
      delete[] powers;
    };
    
    powers=new double[ac+1];
    powers[0]=1;
    for(unsigned int i=0;i<ac;i++){
      powers[i+1]=2*powers[i];
    };    
    npowers=ac;
  };
  
  set *temp=new set[n];
  for(unsigned int i=0;i<n;i++){
    temp[i].assign(n);
  };
  double ans=this->indep_prob(all,temp);
  for(unsigned int i=0;i<n;i++){
    temp[i].clearmem();
  };
  delete[] temp;
  
  return ans;
};    

double setgraph::indep_prob(const set & remain,set *temp){
  //takes a vector of sets as temporary working space to avoid
  //allocating and deleting memory.
  
  double ans1;
  unsigned int i=remain.getfirst();
  remain.writeto(*temp);
  temp->remove(i);
  temp->setminus(edges[i]);
  unsigned int j=temp->getfirst();

  //If the graph is empty, then there are 2^m independent subsets
  for(;j<set::maxcard&&temp->disjoint(edges[j]);temp->getnext(j));
  if(j==set::maxcard){
    ans1=powers[temp->card()];
    //    ans1=ldexp((double)1,temp->card());
  }else{
    ans1=this->indep_prob(*temp,temp+1);
  };
  // ans1 is the conditional probability given that the first element is included.
  
  remain.writeto(*temp);

  temp->remove(i);

  //If the graph is empty, then there are 2^m independent subsets
  for(j=temp->getfirst();j<set::maxcard&&temp->disjoint(edges[j]);temp->getnext(j));
    if(j==set::maxcard){
    ans1+=powers[temp->card()];
    //    ans1+=ldexp((double)1,temp->card());
  }else{
    ans1+=this->indep_prob(*temp,temp+1); 
  };
  return ans1;
};    




double setgraph::indep_prob(const set & remain){   
  //Slower original verion. (Not used)

  double ans1;
  unsigned int i=remain.getfirst();
  if(i==set::maxcard){// shouldn't happen
    return 0;
  };
  set testrem(remain);
  testrem.remove(i);
  testrem.setminus(edges[i]);
  unsigned int j=testrem.getfirst();
  for(;j<set::maxcard&&testrem.intersect(edges[j]).empty();testrem.getnext(j));
  if(j==set::maxcard){
    ans1=pow(2,testrem.card());
  }else{
    ans1=this->indep_prob(testrem);
  };
  // ans1 is the conditional probability given that the first element is included.
  
  remain.writeto(testrem);

  testrem.remove(i);

  for(j=testrem.getfirst();j<set::maxcard&&testrem.intersect(edges[j]).empty();testrem.getnext(j));
  
  if(j==set::maxcard){
    ans1+=pow(2,testrem.card());
  }else{
    ans1+=this->indep_prob(testrem); 
  };
  
  testrem.clearmem();
  return ans1;
};    



void graph::random(){
  for(unsigned int i=0;i<n;i++){
    *(edges+i*(n+1))=2;
    for(unsigned int j=i+1;j<n;j++){
      *(edges+i*n+j)=unif_rand();//   ((double)rand())/RAND_MAX;
      *(edges+j*n+i)=*(edges+i*n+j);
    };
  };
}

double graph::indep_prob(double c){
  return(setgraph(*this,c).indep_prob());
};


class permutation{
public:
  unsigned int n;
  unsigned int *pi;
  permutation(unsigned int sz);
  void random();
  friend std::ostream& operator <<(std::ostream &out,const permutation &p);

};

permutation::permutation(unsigned int sz):n(sz){
  pi=new unsigned int[n];
  for(unsigned int i=0;i<n;i++){
    pi[i]=i;
  };   
};

inline unsigned int randn(unsigned int max){ //repeat of random function defined above.
  unsigned int limit=RAND_MAX-RAND_MAX%max;
  unsigned int ans;
  for(ans=rand();ans>limit;ans=rand());
  return ans%max;
};

void permutation::random(){
  for(unsigned int i=0;i<n-1;i++){
    unsigned int s=::random(n-i);
    unsigned int temp=*(pi+i);
    *(pi+i)=*(pi+i+s);
    *(pi+i+s)=temp;
  };
};

std::ostream& operator <<(std::ostream &out,const permutation &p){
  for(unsigned int i=0;i<p.n;i++){
    out<<*(p.pi+i)<<" ";     
  };
  return out;
};


 
double graph::indep_prob_sample(double c,unsigned int nsamp){
  //uses random sampling to estimate the number of independent sets.
  permutation p(n);
  unsigned int *ifreq=new unsigned int[n+1];
  for(unsigned int i=0;i<=n;i++){
    ifreq[i]=0;
  };
  ifreq[0]=nsamp;
  unsigned int *valid=new unsigned int[n];
  for(unsigned int i=0;i<nsamp;i++){
    p.random();
    for(unsigned int j=0;j<n;j++){
      valid[j]=(*(edges+j*(n+1)))>c;
    };
    unsigned int j=0;
    for(;j<n&&valid[p.pi[j]];j++){
      valid[p.pi[j]]=0;
      for(unsigned int k=0;k<n;k++){
	if(*(edges+p.pi[j]*n+k)<c){
	  valid[k]=0;
	};	
      };
      ifreq[j+1]++;
    };    
  };
  double ans=0;
  double nchoosek=1;
  for(unsigned int i=0;i<=n;i++){
    ans+=nchoosek*((double) ifreq[i])/nsamp;
    nchoosek*=(n-i);
    nchoosek/=(i+1);
  };
  return ans;
};

double graph::indep_prob_sample_inc(double c,unsigned int nsamp){
  //uses random sampling to estimate the number of independent sets.
  permutation p(n);
  unsigned int *ifreq=new unsigned int[n+1];
  unsigned int *ninc=new unsigned int[n+1];
  for(unsigned int i=0;i<=n;i++){
    ifreq[i]=0;
    ninc[i]=0;
  };
  ifreq[0]=nsamp;
  ninc[0]=nsamp*n;
  unsigned int *valid=new unsigned int[n];
  for(unsigned int i=0;i<nsamp;i++){
    p.random();
    for(unsigned int j=0;j<n;j++){
      valid[j]=(*(edges+j*(n+1)))>c;
    };
    unsigned int j=0;
    for(;j<n&&valid[p.pi[j]];j++){
      valid[p.pi[j]]=0;
      for(unsigned int k=0;k<n;k++){
	if(*(edges+p.pi[j]*n+k)<c){
	  valid[k]=0;
	};	
      };
      ifreq[j+1]++;
      for(unsigned int k=0;k<n;k++){
	if(valid[k]){
	  ninc[j+1]++;
	};
      };
    };    
  };
  double ans=n+1;
  double nchoosek=1;
  for(unsigned int i=0;i<=n;i++){
    ans+=nchoosek*((double) ninc[i])/(nsamp*(i+1));
    nchoosek*=(n-i);
    nchoosek/=(i+1);
  };
  return ans;
};


double graph::indep_inc_sample(double c,unsigned int nsamp){
  return(setgraph(*this,c).indep_inc_sample(nsamp));
};

double setgraph::indep_inc_sample(unsigned int nsamp){
  //uses random incremental sampling to estimate the number of independent sets.

  //Deprecated. Do not use.
  
  //Create a list of sets to sample and set then all full.
  set *current=new set[nsamp];
  for(unsigned int i=0;i<nsamp;i++){
    current[i].assign(n);
    current[i].setall();
  };
      
  double *weight=new double[nsamp];

  for(unsigned int i=0;i<nsamp;i++){
    weight[i]=1/(double)nsamp;
  };
  double ans=1;
  double nchk=1;
  
  for(unsigned int i=0;i<n;i++){
    nchk*=((double)(n-i))/(i+1);
    for(unsigned int j=0;j<nsamp;j++){
      unsigned int nchoice=current[j].card();
      weight[j]*=((double)nchoice)/((n-i));
      ans+=weight[j]*nchk;
      if(nchoice){
	unsigned int r=random(nchoice);
	unsigned int addelt=current[j].getelement(r);
	current[j].remove(addelt);
	current[j].setminus(edges[addelt]);
      };
    };
  };
  return ans;
};


double setgraph::indep_inc_sample2(unsigned int nsamp){
  //uses random incremental sampling to estimate the number of independent sets.
  
  //Create a list of sets to sample and set then all full.
  set current(n);
  double ans=0;
  set start(n);
  for(unsigned int j=0;j<n;j++){
    if(!(edges[j].ni(j))){
      start.flip(j);
    };
  };
  unsigned int startchoice=start.card();
  if(startchoice==0){
    return 1;
  };
  for(unsigned int j=0;j<nsamp;j++){
    current=start;
    double weight=1;
    ans+=weight;
    unsigned int nchoice=startchoice;
    for(unsigned int i=0;i<n&&nchoice;i++){
      weight*=((double)nchoice)/(i+1);
      if(nchoice){
	ans+=weight;
	unsigned int r=::random(nchoice);
	unsigned int addelt=current.getelement(r);
	current.remove(addelt);
	current.setminus(edges[addelt]);
      };
      nchoice=current.card();
    };
  };
  return ans/nsamp;
};

double graph::indep_inc_sample2(double c,unsigned int nsamp){
  return(setgraph(*this,c).indep_inc_sample2(nsamp));
};



double graph::indep_inc_sample3(double (*f)(double),unsigned int nsamp,double stepinv){
  //Finds the largest c such that the number of independent sets at
  //cut-off c is more than f(c).

  double clogit=0;
  unsigned int *current=new unsigned int[n];
  
  //Create a list of sets to sample and set them all full.
  for(unsigned int j=0;j<nsamp;j++){
    double eclogit=exp(clogit);
    double c=eclogit/(1+eclogit);
    unsigned int ns=0;
    for(unsigned int j=0;j<n;j++){
      current[j]=(*(edges+j*(n+1))<c)?0:1;
      ns+=current[j];
    };

    unsigned int nchoice=ns;

    //    };
    double weight=1;
    double ans=1;
    for(unsigned int i=0;i<ns&&nchoice;i++){
      weight*=((double)nchoice)/((ns-i));
      if(nchoice){
	ans+=weight;
	unsigned int r=::random(nchoice);
	unsigned int addelt=0;
	for(unsigned int count=0;count<=r;addelt++){
	  if(current[addelt]){
	    count++;
	  };
	};
	addelt--;
	current[addelt]=0;
	nchoice--;
	//	cout<<"Selected node "<<addelt<<" "<<nchoice<<"\n";
	for(unsigned int k=0;k<ns;k++){
	  if(current[k]&&*(edges+addelt*n+k)<c){
	    current[k]=0;
	    nchoice--;
	    //	    cout<<k<<" "<<nchoice<<"\n";
	  };
	};
      };
      //      cout<<"\n";
    };
    double resid=ans/(*f)(c)-1;
    //    cout<<ans<<" "<<(*f)(c)<<" "<<resid<<" ";
    clogit+=resid/stepinv;
    stepinv*=(j+2)/(j+1);
    stepinv++;
  };
  delete[] current;
  return clogit;
};


double graph::indep_inc_sample4(double thresh,unsigned int nsamp,double stepinv){
  //Finds the largest c such that the number of independent sets at
  //cut-off c is more than 2^tc.

  //n is the size of the graph.
  
  double clogit=0;
  unsigned int *current=new unsigned int[n];
  
  //Create a list of sets to sample and set them all full.
  for(unsigned int j=0;j<nsamp;j++){
    double eclogit=exp(clogit);
    double c=eclogit/(1+eclogit);
    unsigned int ns=0;
    for(unsigned int j=0;j<n;j++){
      current[j]=(*(edges+j*(n+1))<c)?0:1;
      ns+=current[j];
    };
    // current is the set of loops less than the current cut-off.
    unsigned int nchoice=ns;

    //    };
    double weight=1;
    double ans=1;
    for(unsigned int i=0;i<ns&&nchoice;i++){
      weight*=((double)nchoice)/(i+1);
      if(nchoice){
	ans+=weight;
	unsigned int r=::random(nchoice); // Choose a random element
					  // to add to the set
	//select the r th element from the available choices.
	unsigned int addelt=0;
	for(unsigned int count=0;count<=r;addelt++){
	  if(current[addelt]){
	    count++;
	  };
	};
	addelt--;
	//remove this element
	current[addelt]=0; 
	nchoice--;
	//remove all choices connected to the new element.
	for(unsigned int k=0;k<n;k++){
	  if(current[k]&&*(edges+addelt*n+k)<c){
	    current[k]=0;
	    nchoice--;
	  };
	};
      };
    };
    //Now ans is (very) approximately the number of independent sets.
    //Calculate the residual 
    double resid=(n-log(ans)/log(2))/(thresh*c)-1;
    clogit+=resid/stepinv;
    stepinv*=(j+2)/(j+1);
//    if(j<50){
//      cout<<"ans="<<ans<<"\tresid="<<resid<<"\tclogit="<<clogit<<"\n";
//    }
    stepinv+=0.1;
  };
  delete[] current;
  return clogit;
};



extern "C"{

  void count_indep(double *answer,const int *n, const double *G, const double *cutoff){
    GetRNGstate();
    unsigned int sz=*n;
    graph Gr(*n,G);
    *answer=Gr.indep_prob(*cutoff);
    PutRNGstate();
  };
  
  void count_indep_perm(double *answer,const int *n, const double *G, const double *cutoff,const int *nsamp){
    GetRNGstate();
    unsigned int sz=*n;
    graph Gr(*n,G);
    *answer=Gr.indep_prob_sample(*cutoff,(unsigned)*nsamp);
    PutRNGstate();
  };
  
  void count_indep_perm_inc(double *answer,const int *n, const double *G, const double *cutoff,const int *nsamp){
    GetRNGstate();
    unsigned int sz=*n;
    graph Gr(*n,G);
    *answer=Gr.indep_prob_sample_inc(*cutoff,(unsigned)*nsamp);
    PutRNGstate();
  };
  
  void count_indep_import(double *answer,const int *n, const double *G, const double *cutoff,const int *nsamp){
    GetRNGstate();
    unsigned int sz=*n;
    graph Gr(*n,G);
    *answer=Gr.indep_inc_sample2(*cutoff,(unsigned)*nsamp);
    PutRNGstate();
  };
  
  void select_cutoff(double *answer,const int *n, const double *G,const int *nsamp,const double *step,const double *threshold){
    GetRNGstate();
    graph Gr(*n,G);
    target_n=*n;
    *answer=Gr.indep_inc_sample4(*threshold,*nsamp,*step);
    PutRNGstate();
  };
  
  void set_level(double *answer,double *level,int *n){
    target_n=*n;
    q=*level;
    *answer=q;
  }

};
