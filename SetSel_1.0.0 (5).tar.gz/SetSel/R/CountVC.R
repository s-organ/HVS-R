count.indep<-function(G,cutoff,method="exact",samp.size=1000){
### Counts the number of independent sets in the graph G at the given cut-off
### G should be a square matrix, representing a graph
    n<-as.integer(dim(G)[1])
    nsamp<-as.integer(samp.size)
    if(dim(G)[1]!=dim(G)[2]){
        stop("Graphs should be represented by a square matrix.")
    }
    ans<-rep(0,length(method))
    answer<-vector("double",1)
    for(i in seq_along(method)){
        if(method[i]=="exact"){
            returnval<-.C('count_indep',answer,n,G,cutoff)
        }else if(method[i]=="permutation"){
            returnval<-.C('count_indep_perm',answer,n,G,cutoff,nsamp)
        }else if(method[i]=="permutation_incremental"){
            returnval<-.C('count_indep_perm_inc',answer,n,G,cutoff,nsamp)

        }else if(method[i]=="importance_sample"){
            returnval<-.C('count_indep_import',answer,n,G,cutoff,nsamp)
        }else{
            warning(paste("Unknown method: \"",method[i],"\" returning 0."),sep="")
            returnval<-0
        }
        ans[i]<-returnval[[1]]
        names(ans)[i]<-method[i]
    }
    return(ans)
}

count.vc<-count.indep
### there are the same number of vertex covers and independent sets.


getqstar<-function(q){
### qstar satisfies qstar(1-log(qstar))=q
    qstar<-q/(1-log(q))
    resid<-1
    while(any(abs(resid)>1e-10)){
        resid<-q-qstar*(1-log(qstar))
        deriv<- -log(qstar)+1e-20 # add a small constant to avoid errors
        qstar<-qstar+resid/deriv
    }
    return(qstar)
}

select.cutoff<-function(G,nstep=10000,step=1,level=0.05,threshold=NULL){
### Finds the value of c such that the number of vertex covers is
### equal to the target function. Currently the target function and
### level are fixed. Need to add flexibility to change this.  G should
### be a square matrix, representing a graph
    
    n<-as.integer(dim(G)[1])
    nst<-as.integer(nstep)
    if(dim(G)[1]!=dim(G)[2]){
        stop("Graphs should be represented by a square matrix.")
    }
    answer<-vector("double",1)
    if(is.null(threshold)){
### Set threshold 
        qstar<-getqstar(level)
        K<-n*(n+1)/2*sum(1/seq_len(n))-(n)*(n-1)/2*log(1.5)/log(2)*(1-1/n)-(n-1)/(2*(n+1))
        threshold<-K/qstar
    }
    returnval<-.C('set_level',answer,level,n)
    
    returnval<-.C('select_cutoff',answer,n,G,nst,step,threshold)
    return(list("level"=level,"threshold"=threshold,"logit"=returnval[[1]],"probability"=exp(returnval[[1]])/(1+exp(returnval[[1]]))))
}

